package modelo;

/**
 *
 * @author ediso
 */
public class Usuario {
   private int idUsuario;
    public String nomUsuario;
    private String contrasena;
    
    public Usuario (){
        this.idUsuario=0;
        this.nomUsuario="";
        this.contrasena="";
    }
 
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNomUsuario() {
        return nomUsuario;
    }

    public void setNomUsuario(String nomUsuario) {
        this.nomUsuario = nomUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

   
}
