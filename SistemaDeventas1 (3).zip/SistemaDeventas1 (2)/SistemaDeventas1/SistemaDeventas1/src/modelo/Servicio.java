package modelo;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
//import java.text.SimpleDateFormat;

public class Servicio {
    
    //atributos
    private int IdServicio;
    private String fechaIngreso;
    private String tipoServicio;
    private String descripcion;
    private String estatus;
   
    
    
    public Servicio() throws ParseException{
    this.fechaIngreso="";
    this.tipoServicio="";
    this.descripcion="";
    this.estatus="";
    }

    public Servicio(int idServicio, String fechaIngreso, String tipoServicio, String descripcion, String estatus,int numeroPlacas,int idCliente, int idEntrega) {
        this.IdServicio=idServicio;
        this.fechaIngreso = fechaIngreso;
        this.tipoServicio = tipoServicio;
        this.descripcion = descripcion;
        this.estatus = estatus;
     
    }

    public int getIdServicio(){
        return IdServicio;
    }
    
    public void setIdServicio(int IdServicio){
        this.IdServicio = IdServicio;
    }
    
    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }


     
    
}