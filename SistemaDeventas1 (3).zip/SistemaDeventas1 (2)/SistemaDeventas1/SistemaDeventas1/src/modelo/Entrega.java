
package modelo;

/**
 *
 * @author abere
 */
import java.sql.Date;

public class Entrega extends Usuario {

    private int idEntrega;
    private Date fechaEntrega;
    private Date proximoServicio;
    public Entrega(){
    //this.fechaEntrega=;
    //this.proximoServicio=;
    }


    public Entrega(int idEntrega,String nomUsuario,Date fechaEntrega, Date proximoServicio) {
        this.idEntrega=idEntrega;
        this.fechaEntrega= fechaEntrega;
        this.proximoServicio = proximoServicio;
        this.nomUsuario=nomUsuario;
    }

    public int getIdEntrega(){
        return idEntrega;
    }

    public void setIdEntrega(int id){
        this.idEntrega=idEntrega;
    }


    public Date getFechaEntrega(){
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEnt){
        this.fechaEntrega=fechaEntrega;
    }
    
    public Date getProximoServicio(){
        return proximoServicio;
    }

    public void setProximoServicio(Date proxServ){
        this.proximoServicio=proximoServicio;
    }

    public String getNomUsuario(){
        return nomUsuario;
    }

}