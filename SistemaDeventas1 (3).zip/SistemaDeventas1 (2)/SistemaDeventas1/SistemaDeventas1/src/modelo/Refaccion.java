package modelo;

/**
 *
 * @author ediso
 */
public class Refaccion {
    
    private int idRefaccion;
    private String modelo;
    private String marca;
    private String pieza;
    private String tipo;
    
    public Refaccion(){
        this.idRefaccion = 0;
        this.modelo = "";
        this.marca = "";
        this.pieza="";
        this.tipo="";
    }

    public Refaccion(int idRefaccion, String modelo, String marca,String pieza, String tipo) {
        this.idRefaccion=idRefaccion;
        this.modelo = modelo;
        this.marca = marca;
        this.pieza = pieza;
        this.tipo=tipo;
    }

    public int getIdRefaccion() {
        return idRefaccion;
    }

    public void setIdRefaccion(int idRefaccion) {
        this.idRefaccion = idRefaccion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPieza() {
        return pieza;
    }

    public void setPieza(String pieza) {
        this.pieza = pieza;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}
