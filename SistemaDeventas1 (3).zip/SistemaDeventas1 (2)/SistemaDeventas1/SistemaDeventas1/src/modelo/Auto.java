package modelo;

public class Auto {
    
    //Atributos
    public int numeroPlacas;
    private String marca;
    private int anio;
    private String modelo;
    public int idCliente;
   
    
    //Contructor
    public Auto(){
        this.numeroPlacas = 0;
        this.marca = "";
        this.anio = 0;
        this.modelo = "";
       this.idCliente = 0;
       
    }
    //Contructor sobrecargado
    public Auto(int numeroPlacas, String marca, int anio, String modelo, int idCliente) {
        this.numeroPlacas = numeroPlacas;
        this.marca = marca;
        this.anio = anio;
        this.modelo = modelo;
        this.idCliente = idCliente;
    }

    public int getNumeroPlacas() {
        return numeroPlacas;
    }

    public void setNumeroPlacas(int numeroPlacas) {
        this.numeroPlacas = numeroPlacas;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    
    
}
