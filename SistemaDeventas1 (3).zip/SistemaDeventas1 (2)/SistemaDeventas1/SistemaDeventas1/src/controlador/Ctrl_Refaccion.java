package controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Refaccion;


public class Ctrl_Refaccion {

    
    public boolean guardar(Refaccion objeto) {
        boolean respuesta = false;
        Connection cn = conexion.Conexion.conectar();
        try {

            PreparedStatement consulta = cn.prepareStatement("insert into refaccion values(?,?,?,?,?)");
            consulta.setInt(1, 0);
            consulta.setString(2, objeto.getModelo());
            consulta.setString(3, objeto.getMarca());
            consulta.setString(4, objeto.getPieza());
            consulta.setString(5, objeto.getTipo());
            

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }

            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al guardar refaccion: " + e);
        }

        return respuesta;
    }

    /**
     * ********************************************************************
     * metodo para consultar si la categoria registrado ya existe
     * ********************************************************************
     */
    public boolean existeRefaccion(String refaccion) {
        boolean respuesta = false;
        String sql = "select idRefaccion from refaccion  where idRefaccion = '" + refaccion + "';";
        Statement st;

        try {
            Connection cn = Conexion.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar refaccion: " + e);
        }
        return respuesta;
    }
    
     /**
     * **************************************************
     * metodo para actualizar una nueva categoria
     * **************************************************
     */
    public boolean actualizar(Refaccion objeto, int idRefaccion) {
        boolean respuesta = false;
        Connection cn = conexion.Conexion.conectar();
        try {

            PreparedStatement consulta = cn.prepareStatement("UPDATE refaccion SET  modelo = ?,marca = ?, pieza = ?, tipo = ? WHERE idRefaccion ='" + idRefaccion + "'");
           
            consulta.setString(1, objeto.getModelo());
            consulta.setString(2, objeto.getMarca());
            consulta.setString(3, objeto.getPieza());
            consulta.setString(4, objeto.getTipo());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }

            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al actualizar refaccion: " + e);
        }

        return respuesta;
    }
    
    
    /**
     * **************************************************
     * metodo para eliminar una nueva categoria
     * **************************************************
     */
    public boolean eliminar(int idRefaccion) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {

            PreparedStatement consulta = cn.prepareStatement(
                    "delete from refaccion where idRefaccion ='" + idRefaccion + "'");
            consulta.executeUpdate();
           
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }

            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al eliminar refaccion: " + e);
        }

        return respuesta;
    }
}
