package controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Servicio;


public class Ctrl_Servicio {

    public boolean guardar(Servicio objeto) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("insert into servicio values(?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getFechaIngreso());
            consulta.setString(3, objeto.getTipoServicio());
            consulta.setString(4, objeto.getDescripcion());
            consulta.setString(5, objeto.getEstatus());
          
     
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar servicio: " + e);
        }
        return respuesta;
    }

    /**
     * ********************************************************************
     * metodo para consultar si el serv ya esta registrado en la BBDD
     * ********************************************************************
     */
    public boolean existeServicio(String servicio) {
        boolean respuesta = false;
        String sql = "select idServicio from servicio where idServicio = '" + servicio + "';";
        Statement st;
        try {
            Connection cn = Conexion.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar servicio: " + e);
        }
        return respuesta;
    }

  
    public boolean actualizar(Servicio objeto, int IdServicio) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {

            PreparedStatement consulta = cn.prepareStatement("update servicio set fechaIngreso=?, tipoServicio = ?, descripcion= ?, estatus = ? where idServicio ='" + IdServicio + "'");
            consulta.setString(1, objeto.getFechaIngreso());
            consulta.setString(2, objeto.getTipoServicio());
            consulta.setString(3, objeto.getDescripcion());
            consulta.setString(4, objeto.getEstatus());
         
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar servicio: " + e);
        }
        return respuesta;
    }

   
    public boolean eliminar(int IdServicio) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement(
                    "delete from servicio where idServicio ='" + IdServicio + "'");
            consulta.executeUpdate();

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar servicio: " + e);
        }
        return respuesta;
    }

}
