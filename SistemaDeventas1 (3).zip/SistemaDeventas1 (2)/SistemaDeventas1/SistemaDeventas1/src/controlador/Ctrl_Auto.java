package controlador;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Auto;


public class Ctrl_Auto{
     /**
     * **************************************************
     * metodo para guardar un nuevo auto
     * **************************************************
     */
    public boolean guardar(Auto objeto) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {

            PreparedStatement consulta = cn.prepareStatement("insert into auto values(?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getMarca());
            consulta.setInt(3, objeto.getAnio());
            consulta.setString(4, objeto.getModelo());
            consulta.setInt(5, objeto.getIdCliente());

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }

            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al guardar auto: " + e);
        }

        return respuesta;
    }

    /**
     * ********************************************************************
     * metodo para consultar si el producto ya esta registrado en la BBDD
     * ********************************************************************
     */
    public boolean existeAuto(String auto) {
        boolean respuesta = false;
        String sql = "select numeroPlacas from auto where numeroPlacas = '" + auto + "';";
        Statement st;

        try {
            Connection cn = Conexion.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar auto: " + e);
        }
        return respuesta;
    }
    
     /**
     * **************************************************
     * metodo para actualizar un producto
     * **************************************************
     */
    public boolean actualizar(Auto objeto, int numeroPlacas) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {

            PreparedStatement consulta = cn.prepareStatement("update auto set marca=?, anio = ?, modelo = ? where numeroPlacas ='" + numeroPlacas + "'");
            consulta.setString(1, objeto.getMarca());
            consulta.setInt(2, objeto.getAnio());
            consulta.setString(3, objeto.getModelo());
         
           
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar auto: " + e);
        }
        return respuesta;
    }
    
    
    /**
     * **************************************************
     * metodo para eliminar un producto
     * **************************************************
     */
    public boolean eliminar(int numeroPlacas) {
        boolean respuesta = false;
        Connection cn = Conexion.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement(
                    "delete from auto where numeroPlacas ='" + numeroPlacas + "'");
            consulta.executeUpdate();
           
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar producto: " + e);
        }
        return respuesta;
    }
    
    /**
     * **************************************************
     * metodo para actualizar stock un producto
     * **************************************************
     */
    
//     public boolean actualizarStock(Producto object, int idProducto) {
//        boolean respuesta = false;
//        Connection cn = Conexion.conectar();
//        try {
//            PreparedStatement consulta = cn.prepareStatement("update tb_producto set cantidad=? where idProducto ='" + idProducto + "'");
//            consulta.setInt(1, object.getCantidad());
//
//            if (consulta.executeUpdate() > 0) {
//                respuesta = true;
//            }
//            cn.close();
//        } catch (SQLException e) {
//            System.out.println("Error al actualizar stock del producto: " + e);
//        }
//        return respuesta;
//    }
}
